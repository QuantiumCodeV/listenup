<?php

$link = "fsdf";